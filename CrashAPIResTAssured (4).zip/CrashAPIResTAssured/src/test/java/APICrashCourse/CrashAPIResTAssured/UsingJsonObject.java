package APICrashCourse.CrashAPIResTAssured;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;
import static  io.restassured.RestAssured.*;

public class UsingJsonObject {

	public static void main(String[] args) {
		
		
		
		RestAssured.baseURI="https://reqres.in";
		
		JSONObject payload=new JSONObject();
		payload.put("name", "murphy");
		payload.put("job", "tester");
		
	String Response=	given().log().all().body(payload.toJSONString()).
		when().post("api/users").then().extract().response().asString();
	System.out.println(Response);
		
		
		

	}

}
