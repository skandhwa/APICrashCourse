package APICrashCourse.CrashAPIResTAssured;

import static io.restassured.RestAssured.given;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PayloadData.Payload;
import Utilities.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class UsingDataProvidertoPassMultipleData {
	
	@DataProvider(name="BooksData")
	public Object [][] getData()
	{
		return new Object[][]
				
				{
			
			{"rtylk",9543},
			{"ghtre",7632},
			{"okmfe",5324},
			{"tkmfe",8324}
			
			
				};
	}
	
	
	@Test(dataProvider="BooksData")
	public void addBook(String isbn,int aisle)
	{
		RestAssured.baseURI="http://216.10.245.166";
		String Response=	given().log().all()
			.body(Payload.AddBook(isbn,aisle)).when().post("Library/Addbook.php")
			
			.then().log().all().statusCode(200).extract().response().asString();
		
		JsonPath js1=ReUsableMethods.rawToJson(Response);
	 String ExpectedID=	js1.getString("ID");
	}
	
	
	
	
	

}
