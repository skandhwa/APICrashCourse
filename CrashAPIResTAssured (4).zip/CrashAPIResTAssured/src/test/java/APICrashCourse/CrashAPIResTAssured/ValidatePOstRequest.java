package APICrashCourse.CrashAPIResTAssured;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;

import org.testng.Assert;

import PayloadData.Payload;
import Utilities.ReUsableMethods;

public class ValidatePOstRequest {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
		String Date="2024-03-15";
		
	String Response=	given().log().all().header("Content-Type","application/json")
		.body(Payload.AddName()).when().post("api/users")
		
		.then().log().all().statusCode(201).extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=ReUsableMethods.rawToJson(Response);
	
	String CreatedDate=js.getString("createdAt");
	System.out.println(CreatedDate);
	
	String []str=CreatedDate.split("T");
	
	System.out.println(str[0]);
	
	Assert.assertEquals(Date, str[0]);
	
	System.out.println("Test Case Passed");
	
	
String JobRole=	js.getString("job");
System.out.println(JobRole);





	
		

	}

}
