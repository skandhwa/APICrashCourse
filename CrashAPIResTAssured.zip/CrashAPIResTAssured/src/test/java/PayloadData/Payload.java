package PayloadData;

public class Payload {
	
	public static String AddName()
	{
		String Payload="{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}";
		
		return Payload;
	}
	
	

}
