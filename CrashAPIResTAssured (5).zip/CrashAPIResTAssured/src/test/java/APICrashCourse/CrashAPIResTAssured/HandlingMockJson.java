package APICrashCourse.CrashAPIResTAssured;

import org.testng.Assert;

import PayloadData.Payload;
import io.restassured.path.json.JsonPath;


public class HandlingMockJson {

	public static void main(String[] args) {
		
		JsonPath js1=new JsonPath(Payload.CoursesFile());
		
		
		///Print No of courses returned by API
	int x=	js1.getInt("courses.size()");
	System.out.println("The total number of courses are "+x);

	///Print Purchase Amount
int purchase_amount=	js1.getInt("dashboard.purchaseAmount");
System.out.println("The total purchase amount is  "+purchase_amount);


///Print Title of the first course

String title=js1.getString("courses[1].title");
System.out.println("The title of second course is  "+title);


///Print All course titles and their respective Prices
System.out.println("The Title and Prices are as follows");

for(int i=0;i<x;i++)///
{
	String Title=js1.getString("courses[ "+i+"    ].title");
	int Price=js1.getInt("courses["+i+"     ].price");
	
	System.out.print("The Title of Course is   "+Title +"  ");
	System.out.println("The Price of Course is   "+Price);
	
	
	
}

//Print number of copes sold by RPA

int z=js1.getInt("courses[2].copies");
System.out.println("The number of copies are "+z);


int sum=0;

for(int i=0;i<x;i++)///
{
	int copies=js1.getInt("courses[ "+i+"    ].copies");
	int prices1=js1.getInt("courses["+i+"     ].price");
	
	int amount=copies*prices1;
	System.out.println("The total amount is "+amount);
	
	sum=sum+amount;
	
	
	
	
	
}



System.out.println("The total Sum value is  "+sum);


Assert.assertEquals(purchase_amount, sum);



	
		

	}

}
