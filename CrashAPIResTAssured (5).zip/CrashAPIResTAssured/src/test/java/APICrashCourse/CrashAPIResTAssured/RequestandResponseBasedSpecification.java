package APICrashCourse.CrashAPIResTAssured;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import PayloadData.Payload;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class RequestandResponseBasedSpecification {

	public static void main(String[] args) {
		
		
		
		
		RequestSpecification req=new RequestSpecBuilder().setBaseUri("https://reqres.in")
				.setContentType(ContentType.JSON).build();
		ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(201).build();
		
		RequestSpecification res=given().spec(req).body(Payload.AddPayload("Manish", "QA"));
		
	
		Response response=res.when().post("api/users").then().spec(respec).extract().response();
		
		String Response=response.asString();
		System.out.println(Response);
		
		System.out.println();
		System.out.println();
		
		RequestSpecification res1=given().spec(req).queryParam("page", 2);
		ResponseSpecification respec1=new ResponseSpecBuilder().expectStatusCode(200).build();
		
		Response response1=res1.when().get("api/users/2").then().spec(respec1).extract().response();
		
		String Response1=response1.asString();
		System.out.println(Response1);
		
		System.out.println();
		System.out.println();
		
Response response2=res.when().get("api/users").then().spec(respec1).extract().response();
		
		String Response2=response2.asString();
		System.out.println(Response2);
		
		
		
		

	}

}
