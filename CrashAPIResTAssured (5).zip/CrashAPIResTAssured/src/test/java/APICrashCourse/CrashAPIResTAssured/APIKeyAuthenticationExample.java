package APICrashCourse.CrashAPIResTAssured;

import static io.restassured.RestAssured.*;

import io.restassured.RestAssured;

public class APIKeyAuthenticationExample {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://api.openweathermap.org";
	String Response=	given().log().all().queryParam("appid","c4a82761751d8c4a1482e529b39852ad")
		.queryParam("q", "Delhi").
		when().get("data/2.5/weather").then().extract().response().asString();
	System.out.println(Response);
		
		
		

	}

}
