package APICrashCourse.CrashAPIResTAssured;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import Utilities.ReUsableMethods;

public class AddingCookies {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://postman-echo.com";
		
	String Response=	given().cookies(ReUsableMethods.setCookieData()).
			when().get("cookies/set").then().extract().response().asString();
		System.out.println(Response);

	}

}
