package APICrashCourse.CrashAPIResTAssured;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class OAuth2Example {
	
	String Access_Token;
	
	@Test
	public void GenerateAccessToken()
	{
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
		String Client_id="ASyStlg4z4BjlmHNrXnDSLwFzY6j8NwPPE16opmTNUxHYf1IXRThQgb3ZN9uWeq3byeJPHlGXp_Gk2f7";
		String Client_Secret_ID="ECKYHfIutJTW9x6PgRFePjsHJPH5MAomf34tbLqp7xmeckGaZGwM083k7ZHrY1cSnW18IYZcNKOH_chu";
		
	String Response=	given().log().all().auth().preemptive().basic(Client_id, Client_Secret_ID)
		.param("grant_type","client_credentials").when().post("v1/oauth2/token")
		.then().log().all().extract().response().asString();
	
	
	System.out.println(Response);
	
	
	JsonPath js=new JsonPath(Response);
	Access_Token=	js.getString("access_token");

System.out.println();
System.out.println();
	
	System.out.println(Access_Token);
	
	System.out.println();
	System.out.println();
		
		
		
	}
	
	@Test(dependsOnMethods= {"GenerateAccessToken"})
	public void LoginUsingAccessToken()
	{
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
	String Response2=	given().log().all().queryParam("page", 3).queryParam("page_size", 4)
		.auth().oauth2(Access_Token).when().get("v1/invoicing/invoices")
		.then().extract().response().asString();
	
	System.out.println(Response2);
	
	JsonPath js2=new JsonPath(Response2);
	System.out.println();
	System.out.println();
	
String Href=	js2.getString("links[0].href");
System.out.println(Href);
System.out.println();
System.out.println();
		
		
		
	}

	
		
	
		

	}


