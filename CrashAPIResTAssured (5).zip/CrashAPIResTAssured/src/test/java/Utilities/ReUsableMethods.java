package Utilities;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.path.json.JsonPath;

public class ReUsableMethods {
	
	public static JsonPath rawToJson(String response)
	{
		
		JsonPath js=new JsonPath(response);
		return js;
		
	}
	
	public static Map setCookieData()
	{
		
		Map<String,String> mp=new LinkedHashMap<String,String>();
		mp.put("skill1","Python");
		mp.put("skill2","Java");
		mp.put("skill3","SQL");
		
		return mp;
		
	}
	

}
