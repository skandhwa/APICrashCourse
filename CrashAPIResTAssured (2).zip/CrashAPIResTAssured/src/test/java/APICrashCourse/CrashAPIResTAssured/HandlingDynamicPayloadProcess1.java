package APICrashCourse.CrashAPIResTAssured;

import org.testng.Assert;
import org.testng.annotations.Test;

import PayloadData.Payload;
import Utilities.ReUsableMethods;

import static io.restassured.RestAssured.*;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


public class HandlingDynamicPayloadProcess1 {
	
	
	@Test 
	public void handlingDynamicPayload()
	{
		
		String isbn="BNTUY";
		int aisle=4567;
		RestAssured.baseURI="http://216.10.245.166";
	String Response=	given().log().all()
		.body(Payload.AddBook(isbn,aisle)).when().post("Library/Addbook.php")
		
		.then().log().all().statusCode(200).extract().response().asString();
	
	JsonPath js1=ReUsableMethods.rawToJson(Response);
 String ExpectedID=	js1.getString("ID");
 String ActualID=isbn+aisle;
 
 Assert.assertEquals(ExpectedID, ActualID);
 
 System.out.println("Test Case Passed");
		
		
		
	}

}
