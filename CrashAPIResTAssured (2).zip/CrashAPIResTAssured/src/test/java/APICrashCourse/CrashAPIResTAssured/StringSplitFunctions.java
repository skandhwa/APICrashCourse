package APICrashCourse.CrashAPIResTAssured;

public class StringSplitFunctions {

	public static void main(String[] args) {
		
		
		String str="abcd@efgh@ghty";
		
	String []str1=	str.split("@");
	System.out.println(str1[2]);
	

	

}}

