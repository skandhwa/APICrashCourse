package PayloadData;

public class Payload {
	
	public static String AddName()
	{
		String Payload="{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}";
		
		return Payload;
	}
	
	
	public static String AddBook(String ISBN,int AISLE)
	{
		String payload1="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Selenium with Java\",\r\n"
				+ "\"isbn\":\""+ISBN+"\",\r\n"
				+ "\"aisle\":\""+AISLE+"\",\r\n"
				+ "\"author\":\"John Ray\"\r\n"
				+ "}\r\n"
				+ "";
		
		return payload1;
	}
	
	public static String CoursesFile()
	{
		String payload2="{\r\n"
				+ "\r\n"
				+ "\"dashboard\": {\r\n"
				+ "\r\n"
				+ "\"purchaseAmount\": 910,\r\n"
				+ "\r\n"
				+ "\"website\": \"grotechminds.com\"\r\n"
				+ "\r\n"
				+ "},\r\n"
				+ "\r\n"
				+ "\"courses\": [\r\n"
				+ "\r\n"
				+ "{\r\n"
				+ "\r\n"
				+ "\"title\": \"Selenium Python\",\r\n"
				+ "\r\n"
				+ "\"price\": 50,\r\n"
				+ "\r\n"
				+ "\"copies\": 6\r\n"
				+ "\r\n"
				+ "},\r\n"
				+ "\r\n"
				+ "{\r\n"
				+ "\r\n"
				+ "\"title\": \"Cypress\",\r\n"
				+ "\r\n"
				+ "\"price\": 40,\r\n"
				+ "\r\n"
				+ "\"copies\": 4\r\n"
				+ "\r\n"
				+ "},\r\n"
				+ "\r\n"
				+ "{\r\n"
				+ "\r\n"
				+ "\"title\": \"RPA\",\r\n"
				+ "\r\n"
				+ "\"price\": 45,\r\n"
				+ "\r\n"
				+ "\"copies\": 10\r\n"
				+ "\r\n"
				+ "}\r\n"
				+ "\r\n"
				+ "]\r\n"
				+ "\r\n"
				+ "}";
		
		
		return payload2;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
