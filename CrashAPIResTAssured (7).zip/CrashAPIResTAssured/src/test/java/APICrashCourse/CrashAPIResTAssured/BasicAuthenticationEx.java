package APICrashCourse.CrashAPIResTAssured;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class BasicAuthenticationEx {

	public static void main(String[] args) {
		
		RestAssured.baseURI="http://postman-echo.com";
	String Response=	given().relaxedHTTPSValidation().
			log().all().auth().preemptive().basic("postman", "password")
		.when().get("basic-auth").then().extract().response().asString();
	
	System.out.println(Response);
		
		

	}

}
