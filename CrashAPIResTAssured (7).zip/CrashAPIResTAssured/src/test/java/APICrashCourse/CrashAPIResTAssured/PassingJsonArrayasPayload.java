package APICrashCourse.CrashAPIResTAssured;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PassingJsonArrayasPayload {

	public static void main(String[] args) {
		
		Map<String,Object> mp=new HashMap<String,Object>();
		mp.put("name", "morpheus");
		mp.put("job", "leader");
		mp.put("salary", 80000);
		mp.put("Grade", 'A');
		
		Map<String,Object> mp2=new HashMap<String,Object>();
		mp2.put("name", "Tim");
		mp2.put("job", "QA");
		mp2.put("salary", 90000);
		mp2.put("Grade", 'B');
		
		Map<String,Object> mp3=new HashMap<String,Object>();
		mp3.put("name", "John");
		mp3.put("job", "Developer");
		mp3.put("salary", 990000);
		mp3.put("Grade", 'C');
		
		List<Map<String,Object>> li=new ArrayList();
		li.add(mp);
		li.add(mp2);
		li.add(mp3);
		
		
		
		RestAssured.baseURI="https://reqres.in";
	String Response=	given().log().all().body(li).headers("Content-Type","application/json").
			when().post("api/users").then().extract().response().asString();
	System.out.println();
	System.out.println();
		System.out.println(Response);

	}

}
