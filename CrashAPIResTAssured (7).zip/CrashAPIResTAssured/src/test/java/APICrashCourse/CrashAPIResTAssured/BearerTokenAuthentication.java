package APICrashCourse.CrashAPIResTAssured;

import static io.restassured.RestAssured.*;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;

public class BearerTokenAuthentication {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://gorest.co.in";
		
		JSONObject payload=new JSONObject();
		payload.put("name", "murphy");
		payload.put("gender", "male");
		payload.put("email", "adassrra@gmail.com");
		payload.put("status", "active");
		String token="Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";
		
	String Response=	given().log().all().
		headers("Authorization",token).headers("Content-Type","application/json").
		body(payload.toJSONString()).when().post("public/v2/users").then().extract().response().asString();
		
	
	System.out.println(Response);
		
		
		

	}

}
