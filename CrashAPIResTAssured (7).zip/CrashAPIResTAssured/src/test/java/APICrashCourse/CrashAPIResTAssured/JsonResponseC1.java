package APICrashCourse.CrashAPIResTAssured;

public class JsonResponseC1 {
	
	public String name;
	public String job;
	public int id;
	public String createdAt;
	
	

}
