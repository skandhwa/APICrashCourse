package APICrashCourse.CrashAPIResTAssured;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;


import static io.restassured.RestAssured.*;

public class Deserialization {
	
	@Test
	public void test1()
	{
		RestAssured.baseURI="https://reqres.in";
		JSONObject payload=new JSONObject();
		payload.put("name", "Tim");
		payload.put("job", "leader");
		
	Response response= 	given().log().all().headers("Content-Type","application/json").
			body(payload)
		.when().post("api/users").then().extract().response();
	
ResponseBody obj=	response.getBody();
System.out.println(obj);

JsonResponseC1 responseclass=obj.as(JsonResponseC1.class);

System.out.println();
System.out.println();
//System.out.println(responseclass);

Assert.assertEquals(responseclass.name, "Tim" ,"Check the validation for name");

Assert.assertEquals(responseclass.job, "leader","Check the validation for Job");
		
		
		
		
	}
	
	

}
