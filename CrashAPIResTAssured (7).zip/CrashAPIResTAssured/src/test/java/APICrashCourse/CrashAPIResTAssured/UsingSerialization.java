package APICrashCourse.CrashAPIResTAssured;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import PayloadData.Payload;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class UsingSerialization {
	
	@Test
	public void test() throws JsonProcessingException
	{
		
		EmployeePOJOEx emp=new EmployeePOJOEx();
		emp.setName("Tim");
		emp.setLocation("Delhi");
		emp.setSalary(80000);
		emp.setJob("QA");
		
		ObjectMapper obj1=new ObjectMapper();
		
		String empJson=obj1.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		System.out.println(empJson);
		

		RequestSpecification req=new RequestSpecBuilder().setBaseUri("http://httpbin.org/post")
				.setContentType(ContentType.JSON).build();
		ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200).build();
		
		RequestSpecification res=given().spec(req).body(empJson);
		
	
		Response response=res.when().post().then().spec(respec).extract().response();
		
		String Response=response.asString();
		System.out.println();
		System.out.println();
		
		System.out.println(Response);
		
		System.out.println();
		System.out.println();
		
		EmployeePOJOEx emp2=obj1.readValue(empJson, EmployeePOJOEx.class);
		
		System.out.println();
		System.out.println();
		System.out.println("Name  is "+emp.getName());
		System.out.println("Job  is "+emp.getJob());
		
		
		
	}
	
	

}
