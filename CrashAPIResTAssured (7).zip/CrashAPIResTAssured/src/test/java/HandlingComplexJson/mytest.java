package HandlingComplexJson;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class mytest {
	
	@Test
	public void test() throws JsonProcessingException
	{
		
		
		
		
		Employee emp1=new Employee();
		emp1.setFirstname("Mohan");		
		emp1.setAge(32);
		emp1.setGender("Male");
		emp1.setLastname("Roy");
		emp1.setSalary(60000);
		
		
		
		EmployeeAddress empAddress=new EmployeeAddress();
		empAddress.setCity("Pune");
		empAddress.setStreet("Hijewadi");
		empAddress.setPincode(713304);
		empAddress.setState("Maharastra");
		emp1.setAddress(empAddress);
		
		ObjectMapper obj=new ObjectMapper();
	String jsonpayload=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp1);
	System.out.println(jsonpayload);
	
	
	RequestSpecification req=new RequestSpecBuilder().setBaseUri("http://httpbin.org/post").setContentType(ContentType.JSON).build();
	ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200).build();
	
	RequestSpecification res=given().spec(req).body(jsonpayload);
	

	Response response=res.when().post().then().spec(respec).extract().response();
	System.out.println();
	System.out.println();
	
	
	
	String Response1=response.asString();
	System.out.println(Response1);
	
	
	
		
		
		
		
		
	}
	
	

}
