package NestedComplexJsonBlock;

import java.util.List;

public class NestedJsonPojo {
	
	private String companyName;
	private String street;
	private String city;
	private int pincode;
	private List<String> BankAccount;
	private List<Employee> employeelist;
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public List<String> getBankAccount() {
		return BankAccount;
	}
	public void setBankAccount(List<String> bankAccount) {
		BankAccount = bankAccount;
	}
	public List<Employee> getEmployeelist() {
		return employeelist;
	}
	public void setEmployeelist(List<Employee> employeelist) {
		this.employeelist = employeelist;
	}
	
	
	

}
