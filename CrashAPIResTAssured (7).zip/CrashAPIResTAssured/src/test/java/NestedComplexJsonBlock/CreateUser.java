package NestedComplexJsonBlock;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import HandlingComplexJson.Employee;
import HandlingComplexJson.EmployeeAddress;

public class CreateUser {
	
	@Test
	public void createUser()
	{
//		NestedJsonPojo reqPayload=new NestedJsonPojo();
//		reqPayload.setCompanyName("XYZ");
//		reqPayload.setCity("Kolkata");
//		reqPayload.setPincode(700033);
//		reqPayload.setStreet("PR Lane");
//		
//		List<String> banks=new ArrayList<String>();
//		banks.add("HDFC");
//		banks.add("UBI");
//		banks.add("ICICI");
//		reqPayload.setBankAccount(banks);
//		
//		
//		Employee emp1=new Employee();
//		emp1.setFirstname("Mohan");		
//		emp1.setAge(32);
//		emp1.setGender("Male");
//		emp1.setLastname("Roy");
//		emp1.setSalary(60000);
//		
//		EmployeeAddress empAddress=new EmployeeAddress();
//		empAddress.setCity("Pune");
//		empAddress.setStreet("Hijewadi");
//		empAddress.setPincode(713304);
//		empAddress.setState("Maharastra");
//		
//		emp1.setAddress(empAddress);
//		
//		
//		Employee emp2=new Employee();
//		emp2.setFirstname("Rohan");		
//		emp2.setAge(42);
//		emp2.setGender("Male");
//		emp2.setLastname("Rai");
//		emp2.setSalary(90000);
//		
//		EmployeeAddress empAddress2=new EmployeeAddress();
//		empAddress2.setCity("Kolkata");
//		empAddress2.setStreet("Tly");
//		empAddress2.setPincode(713309);
//		empAddress2.setState("WB");
//		
//		emp2.setAddress(empAddress2);
//		
//		Employee emp3=new Employee();
//		emp3.setFirstname("Rohan");		
//		emp3.setAge(42);
//		emp3.setGender("Male");
//		emp3.setLastname("Rai");
//		emp3.setSalary(90000);
//		
//		EmployeeAddress empAddress3=new EmployeeAddress();
//		empAddress3.setCity("Kolkata");
//		empAddress3.setStreet("Tly");
//		empAddress3.setPincode(713309);
//		empAddress3.setState("WB");
//		
//		emp3.setAddress(empAddress3);
//		
//		List<Employee> employees = new ArrayList<Employee>();
//		employees.add(emp1);
//		employees.add(emp2);
//		employees.add(emp3);
//		
//		reqPayload.setEmployeelist(employees);
//		
		
		
		NestedJsonPojo requestPayload = new NestedJsonPojo();
		
		requestPayload.setCompanyName("XYZ Ltd");
		requestPayload.setCity("Arifac Avenue");
		requestPayload.setStreet("RK Puram, Delhi");
		requestPayload.setPincode(10000);
		
		List<String> banks = new ArrayList<String>();
		banks.add("HDFC");
		banks.add("SBI");
		banks.add("AXIS");
		requestPayload.setBankAccount(banks);
		
		List<Employee> li = new ArrayList<Employee>();
		
		Employee emp1 = new Employee();
		Employee emp2 = new Employee();
		Employee emp3 = new Employee();

		emp1.setFirstname("Suresh");
		emp1.setLastname("Mehra");
		emp1.setGender("Male");
		emp1.setAge(35);
		emp1.setSalary(10000.56);
		EmployeeAddress emp1Address = new EmployeeAddress();
		emp1Address.setStreet("Park Avenue");
		emp1Address.setCity("vijaywada");
		emp1Address.setState("Andhra Pradesh");
		emp1Address.setPincode(530012);	
		emp1.setAddress(emp1Address);
		
		
		emp2.setFirstname("Amit");
		emp2.setLastname("Gupta");
		emp2.setGender("Male");
		emp2.setAge(30);
		emp2.setSalary(34000);
		EmployeeAddress empAddress = new EmployeeAddress();
		empAddress.setStreet("Plot 7");
		empAddress.setCity("vijaywada");
		empAddress.setState("Andhra Pradesh");
		empAddress.setPincode(530012);	
		emp2.setAddress(empAddress);
		
		

		emp3.setFirstname("Ashish");
		emp3.setLastname("Das");
		emp3.setGender("Male");
		emp3.setAge(39);
		emp3.setSalary(55000);
		
		empAddress.setStreet("Plot 8");
		empAddress.setCity("Dwarka");
		empAddress.setState("New Delhi");
		empAddress.setPincode(110066);	
		emp3.setAddress(empAddress);
		
		
		li.add(emp1);
		li.add(emp2);
		li.add(emp3);
		
		requestPayload.setEmployeelist(li);

		
		
		
		
		
		
		
		
		
	}
	

}
