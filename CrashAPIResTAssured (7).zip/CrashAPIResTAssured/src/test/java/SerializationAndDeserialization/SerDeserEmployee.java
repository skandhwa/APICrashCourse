package SerializationAndDeserialization;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import PayloadData.Payload;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class SerDeserEmployee {
	
	@Test
	public void test() throws JsonProcessingException
	{
		Employee emp=new Employee();
		emp.setName("Mohan");
		emp.setCity("Delhi");
		//emp.setPincode(713304);
		emp.setState("NCR");
		
		Employee emp1=new Employee();
		emp1.setName("Rohan");
		emp1.setCity("Agra");
		//emp1.setPincode(783213);
		emp1.setState("UP");
		
		Employee emp2=new Employee();
		emp2.setName("Sohan");
		emp2.setCity("Goa");
		//emp2.setPincode(784513);
		emp2.setState("Maharastra");
		
		List<Employee> li=new ArrayList<Employee>();
		li.add(emp);
		li.add(emp1);
		li.add(emp2);
	
		ObjectMapper obj=new ObjectMapper();
	String JsonPayload=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(li);
	System.out.println(JsonPayload);
	
	RequestSpecification req=new RequestSpecBuilder().setBaseUri("http://httpbin.org/post").setContentType(ContentType.JSON).build();
	ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200).build();
	
	RequestSpecification res=given().log().all().
			spec(req).body(JsonPayload);
	

	Response response=res.when().post().then().spec(respec).extract().response();
	System.out.println();
	System.out.println();
	
	
	
	String Response1=response.asString();
	System.out.println(Response1);
	
	ResponseBody responseBody=response.getBody();
	System.out.println(responseBody);
	
	JsonPath js=responseBody.jsonPath();
	
List<Employee> allEmp=	js.getList("json",Employee.class);

;

System.out.println();
System.out.println();

for(Employee x:allEmp)
{
	System.out.println(x.getCity());
	
}


	
	
		
		
		
		
		
		
		
		
		
	}

}
