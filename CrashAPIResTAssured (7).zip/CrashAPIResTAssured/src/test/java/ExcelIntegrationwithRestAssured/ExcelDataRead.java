package ExcelIntegrationwithRestAssured;

import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelDataRead {
	
	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	
	public ExcelDataRead(String excelPath,String sheetName) throws IOException
	{
		workbook= new XSSFWorkbook(excelPath);
		sheet=workbook.getSheet(sheetName);
	}
	
	
	@Test
	public void getData() throws IOException
	{
		
		int x=sheet.getPhysicalNumberOfRows();
		
		System.out.println(x);
		
//	String Value=	sheet.getRow(2).getCell(1).getStringCellValue();
//	System.out.println("The data from excel sheet is "+Value);
//	
		
		
		
		
		
	}
	
	public static Object getCellData(int rownum,int colnum)
	{
		DataFormatter formatter=new DataFormatter();
		Object value=formatter.formatCellValue(sheet.getRow(rownum).getCell(colnum));
		return value;
	}
	
	
	
	
	

}
