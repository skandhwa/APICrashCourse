package ExcelIntegrationwithRestAssured;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import PayloadData.Payload;
import io.restassured.RestAssured;

public class CreateUserThroughExcel {
	
	@Test
	public void createUser() throws IOException
	{
		
RestAssured.baseURI="https://httpbin.org";
		
		String excelPath="src\\main\\java\\TestData\\TestDataCrashGrotech.xlsx";
	String SheetName="Sheet1";
	ExcelDataRead obj1=new ExcelDataRead(excelPath,SheetName);
	Map<Object,Object> mp=new HashMap<Object,Object>();
	mp.put("firstname",obj1.getCellData(1,0));
	mp.put("lastname",obj1.getCellData(1,1));
	
	
	
	
	
	
           


		
	String Response=	given().log().all().header("Content-Type","application/json")
		.body(mp).when().post("post")
		
		.then().log().all().statusCode(200).extract().response().asString();
	
	System.out.println(Response);
		
		
		
		
	}

}
